<?php
echo "<h1>Panel de Administrador</h1>";
echo "<ul>
    <li><a href='productos.php'>CRUD Productos</a></li>
    <li><a href='pedidos.php'>Ver Pedidos</a></li>
    <li><a href='usuarios.php'>Gestión de Usuarios</a></li>
    <li><a href='estadisticas.php'>Estadísticas</a></li>
    <li><a href='transportistas.php'>CRUD Transportistas</a></li>
</ul>";
?>