<?php
$pedidos = ["Pedido #1 - Camisa", "Pedido #2 - Zapato"];
echo "<h2>Pedidos Realizados</h2><ul>";
foreach ($pedidos as $pedido) {
    echo "<li>$pedido</li>";
}
echo "</ul>";
?>