<?php
echo "<h2>Estadísticas</h2>";
echo "<p>Ventas Totales: $5000</p>";
echo "<p>Producto más vendido: Camisa</p>";
?>