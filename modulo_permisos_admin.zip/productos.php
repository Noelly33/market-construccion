<?php
$productos = ["Zapato", "Camisa", "Pantalón"];
echo "<h2>Productos</h2><ul>";
foreach ($productos as $p) {
    echo "<li>$p <a href='#'>Editar</a> <a href='#'>Eliminar</a></li>";
}
echo "</ul><button>Agregar Producto</button>";
?>