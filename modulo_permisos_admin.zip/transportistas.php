<?php
$transportistas = ["Transporte A", "Transporte B"];
echo "<h2>Transportistas</h2><ul>";
foreach ($transportistas as $t) {
    echo "<li>$t <a href='#'>Editar</a> <a href='#'>Eliminar</a></li>";
}
echo "</ul><button>Agregar Transportista</button>";
?>