<?php
$usuarios = ["admin", "cliente01", "cliente02"];
echo "<h2>Gestión de Usuarios</h2><ul>";
foreach ($usuarios as $u) {
    echo "<li>$u</li>";
}
echo "</ul>";
?>